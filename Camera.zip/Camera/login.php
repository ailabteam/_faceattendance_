<?php session_start() ?>
<!DOCTYPE HTML>
<html>
<head>
	<title>Login</title>
	<script src="js/jquery.min.js"></script>
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
	<!-- for-mobile-apps -->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
	<meta name="keywords" content="Classy Login form Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

	<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700' rel='stylesheet' type='text/css'>
</head>
<body>
	<?php  
		$error = null;
		if (isset($_POST["btnsub"])) {
			if ($_POST["name"] == "1751220004" && $_POST["password"] == "123" ) {
				$_SESSION["user"] = $_POST["name"];
				header("location:demo.php");
				exit();
			}
			else{
				$error = "Nhập Sai Thông Tin. Nhập Lại...";
			}
		}
	?>
<!--header start here-->
	<div class="header">
		<div class="header-main">
		    <h1>Đăng Nhập <br><font style="font-size: 13px;color: red"><?php echo $error; ?></font></h1>

			<div class="header-bottom">
				<div class="header-right w3agile">
					
					<div class="header-left-bottom agileinfo">
						
					 <form action="#" method="post">
						<input type="text"  value="" name="name" />
						<input type="password"  value="" name="password"/>
						<input type="submit" value="Đăng Nhập" name="btnsub">
					</form>	
					
						
				</div>
				</div>
			  
			</div>
		</div>
	</div>

</body>
</html>