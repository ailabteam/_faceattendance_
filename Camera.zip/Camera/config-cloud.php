	<?php 
	\Cloudinary::config(array( 
	  "cloud_name" => "minn", 
	  "api_key" => "383271541361979", 
	  "api_secret" => "p0Tv4l1p10MdDG0VlZa275sBmEA", 
	));
	
 ?>	