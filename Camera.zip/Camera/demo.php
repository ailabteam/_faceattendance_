<!DOCTYPE html>
<html>
<head>
	<title>cam</title>
	<style type="text/css">
		body{
			background-color: #3c5298e3;
			position: relative;
			padding: 0;
			margin: 0;
		}
		
		#Main{
			width: 90%;
			overflow: hidden;
			margin: 0px 5%;
		}
		#left{
			float: left;
			width: 30%;
			text-align: center;
		}
		#mid{
			float: left;
			width: 40%;
			text-align: center;

		}
		#right{
			float: left;
			width: 30%;
			text-align: center;
		}

		#content{
			clear: both;
			width: 71%;
			margin: auto;
			overflow: hidden;
		}
		#bottom_content{
			text-align: center;
			clear: both;
		}
		#add-canvas{
			overflow: hidden;
		}
		.picture{
			float: left;
			margin-left: 20px;
			margin-top: 10px;
			transition: 1s;
			height: 130px;

		}
		.picture:hover{
			box-shadow: 0px 0px 5px 5px black;
			height: 130px;
		}
		.vidio{
			margin-top: 60px;
			height: 150px;
			width: 100%;
		}
		#chup button{
			height: 31px;
		    width: 64px;
		    border-radius: 14px;
		    margin-top: 10px;
		}
		#animate{
			width: 50px;
		    height: 50px;
		    position: absolute;
		    background-color: red;
		    text-align: center;
		}
		#animate h1{
			line-height: 10px;
			font-size: 20px;
		}
		#all {
		  	width: 100%;
		  	height: 100vh;
		 	overflow: auto;
		  	position: relative;
		  	background: #f5f4eeeb;
		}
		.btn{
			padding: 0px 10px;
    		margin-top: 10px;
		}
		#divlink table{
			width: 60%;
			margin: auto;
			margin-bottom: 10px;
		}
		#left table , #right table {
			border-collapse: collapse;
			width: 75%;
			margin: auto;
		}
		#left tr , #right tr{
			border: 1px solid #c5b1b180;
			height: 50px;
		}


	</style>
	<script src="http://hongru.github.io/proj/canvas2image/canvas2image.js"></script>
	<!-- use cam -->
	<script type="text/javascript"> 
		var constraints = { video: true }; 
		navigator.mediaDevices.getUserMedia(constraints)
		.then(function(mediaStream) {
		    var video = document.querySelector('#video');
			video.srcObject = mediaStream;
		video.onloadedmetadata = function(e) {
		    video.play();
		  };
		})
		.catch(function(err) { console.log(err.name + ": " + err.message); });
	</script>
	
</head>
<body>
	<?php 
			require "vendor/autoload.php";
			require "config-cloud.php";;
			if(isset($_POST["btnsub"])){
				$sec = $_POST["txtMS"];
				// $link = "https://res.cloudinary.com/minn/image/upload/".$sec."/".$sec;
				echo $sec;
				$arrayLink = array();
				for ($index=1; $index <= 8 ; $index++) { 
					$direct = $_POST["link"]."/".$sec."_".$index.".png";
					$direct2 = "".$sec."/".$sec."_".$index;
					$ress = \Cloudinary\Uploader::upload($direct,array("public_id"=> $direct2));
					$arrayLink[$index] = $ress;
				}
				// $api = new \Cloudinary\Api();
				// $result = $api->resource("sample");
				// echo $result;
				echo "<script type=\"text/javascript\">alert(\"Done ! Uploaded to server\");</script>";
				echo "<pre>";
				
				
				$myFile = "Image_Link/".$sec.".txt";
				if(file_exists($myFile)){
					$oldfile = fopen($myFile, 'a');
					foreach( $arrayLink as $value )
				    {
				        // print_r($value["url"]);
				        fwrite($oldfile,$value["url"]."\n");
				    }  
				    fclose($oldfile);
				}
				else{
					$newfile = fopen($myFile, "w");
					foreach( $arrayLink as $value )
				    {
				        // print_r($value["url"]);
				        fwrite($newfile,$value["url"]."\n");
				    } 
				    fclose($newfile);
				}
				
				header('location:demo.php');
				// echo "<a href='logout.php'></a>";
				// echo cloudinary_url("1751220004", array("type"=>"list"));
				// echo cl_image_tag("1751220004_1.png");

			}
	?>

	<div id="all">
		<div id="animate">
			<h1 id="count-down"></h1>
		</div>
		<div id="Main">
			<div id="left">
				<h3>Thông Tin</h3>
					<table>
						<tr>
							<td>Mã số</td>
							<td>:</td>
							<td><input type="text" name="txtMs" id="txtMs"></td>
						</tr>
						<tr>
							<td>Thời gian</td>
							<td>:</td>
							<td><p id="demo"></p></td>
						</tr>
					</table>
			</div>
			<div id="mid">
				<video class="vidio" autoplay="true" id="video"></video>
				<a class="chup" id="chup" onclick="count()"><button >Bắt đầu</button></a>
			</div>
			<div id="right">
				<h3>Tùy Chọn</h3>
				<table>
					<tr>
						<td>Kích thước</td>
						<td>:</td>
						<td>
							<select id="kichthuoc" onchange="sizeChange()">
								<option value="3" selected>213x160</option>
								<option value="2">320x240</option>
								<option value="1">640x480</option>
							</select>
						</td>

					</tr>
					<tr>
						<td>Đăng xuất</td>
						<td>:</td>
						<td><a href="logout.php"><button>Đăng xuất</button></a></td>
					</tr>
				</table>
			</div>
		</div>
		<div id="content">
			<div id="bottom_content">
				<form method="POST" enctype="multipart/form-data" style="width: 81%;margin: auto;">
					<div id="divlink">
						<table>
							<tr>
								<td><label id="txtlink">Đường dẫn tới mục Download của bạn :</label></td>
							</tr>
							<tr>
								<td><input type="text" name="link" id="link" value="C:\Users\Minh-dtr\Downloads"></td>
							</tr>
						</table>
					</div>
					<div id="form_content">
						
					</div>
					<div style="clear: both;">
						<input type="text" name="txtMS" id="txtMS" hidden="true" style="display: none">
						<input style="clear: both;" class="btn" type="submit" id="btnsub" name="btnsub" value="Upload" hidden="true">
					</div>
				</form>
				<button id="btnDownload" class="btn"  onclick="load()" hidden="true" >DownLoad</button>
			</div>
		</div>
	</div>
	<script>
		var myVar = setInterval(myTimer, 1000);

		function myTimer() {
		  var d = new Date();
		  document.getElementById("demo").innerHTML = d.toLocaleTimeString();
		}

	</script>
	<script type="text/javascript">
		var kichthuoc = 3;
		function sizeChange(){
			kichthuoc = document.getElementById('kichthuoc').value;
			console.log(kichthuoc);
		}



		function setCanvas(indexCanvas,kichthuoc){
					
					var vas = document.createElement('canvas');
					vas.id = "thecanvas"+indexCanvas;
					vas.classList.add("picture");
					var video = document.getElementById('video');
				    vas.width = video.videoWidth/kichthuoc; //set độ rộng canvas = video
				    vas.height = video.videoHeight/kichthuoc;
				    vas.getContext('2d').drawImage(video, 0, 0,video.videoWidth/kichthuoc,video.videoHeight/kichthuoc);
				    var contentform = document.getElementById('form_content');
					contentform.appendChild(vas);
		}
		function myMoverow(preview,next) {
		  	var elemrow = document.getElementById("animate");   
		  	var idrow = setInterval(framerow, 5);
	  		var posrow = preview;
		  	
		  	function framerow() {
		    	if (posrow >= next) {
		     	 	clearInterval(idrow);
		   	 	}

		   	 	else {
		      		posrow+=5; 
		      		elemrow.style.left = posrow + "px"; 
		    	}
		  	}
		}
		function myMovecol(preview,next) {
		  	var elemcol = document.getElementById("animate");   
		  	var idcol = setInterval(framecol, 5);
		  	var poscol = preview;
		  	function framecol() {
		    	if (poscol >= next) {
		     	 	clearInterval(idcol);
		   	 	} 
		   	 	else {
		      		poscol+=5; 
		      		elemcol.style.top = poscol + "px"; 
		    	}
		  	}
		}
		function myMoverowelse(preview,next) {
		  	var elemrowelse = document.getElementById("animate");   
		  	var idrowelse = setInterval(framerowelse, 5);
	  		var posrowelse = preview;
		  	
		  	function framerowelse() {
		    	if (posrowelse <= next) {
		     	 	clearInterval(idrowelse);
		   	 	}

		   	 	else {
		      		posrowelse-=5; 
		      		elemrowelse.style.left = posrowelse + "px"; 
		    	}
		  	}
		}
		function myMovecolelse(preview,next) {
		  	var elemcolelse = document.getElementById("animate");   
		  	var idcolelse = setInterval(framecolelse, 5);
		  	var poscolelse = preview;
		  	function framecolelse() {
		    	if (poscolelse <= next) {
		     	 	clearInterval(idcolelse);
		   	 	} 
		   	 	else {
		      		poscolelse-=5; 
		      		elemcolelse.style.top = poscolelse + "px"; 
		    	}
		  	}
		}
		function count(){
			setTimeout('document.getElementById(\"count-down\").innerHTML = "3"',1000);
			setTimeout('document.getElementById(\"count-down\").innerHTML = "2"',2000);
			setTimeout('document.getElementById(\"count-down\").innerHTML = "1"',3000);
			setTimeout('to_image()',4000);
			
		}
		
		var tick = 1;
		function to_image(){
			if(document.getElementById('link').value == ""){
				alert('vui lòng dán đường link đến thư mục Download trên máy tính của bạn !');
			}
			else if(document.getElementById('txtMs').value == ""){
				alert('vui lòng nhập mã số sinh viên !');
			}
			else{
				

				// document.getElementsByClassName("chup")[0].click();
				var widthAll = document.getElementById("all").clientWidth;
				var heightAll = document.getElementById("all").clientHeight;

				console.log(widthAll);
				switch(tick){
					case 1: 
						count();
						setCanvas(1,kichthuoc);
						myMoverow(0,Math.round(widthAll/2)-26);
						tick+=1;
						break;
					case 2:
						count();
						setCanvas(2,kichthuoc);
						myMoverow(Math.round(widthAll/2)-26,Math.round(widthAll-50));
						tick+=1;
						break;
					case 3: 
						count();
						setCanvas(3,kichthuoc);
						myMovecol(0,Math.round(heightAll/2)-27);
						tick+=1;
						break;
					case 4:
						count();
						setCanvas(4,kichthuoc);
						myMovecol(Math.round(heightAll/2)-26,Math.round(heightAll-50));
						tick+=1;
						break;
					case 5: 
						count();	
						setCanvas(5,kichthuoc);
						myMoverowelse(Math.round(widthAll-50),Math.round(widthAll/2)-26);
						tick+=1;
						break;
					case 6: 
						count();
						setCanvas(6,kichthuoc);
						myMoverowelse(Math.round(widthAll/2)-26,0);
						tick+=1;
						break;
					case 7: 
						count();
						setCanvas(7,kichthuoc);
						myMovecolelse(Math.round(heightAll-50),Math.round(heightAll/2)-26);
						tick+=1;
						break;
					case 8: 
						setCanvas(8,kichthuoc);
						myMovecolelse(Math.round(heightAll/2)-26,0);
						document.getElementById('count-down').innerHTML = "Done!";
						tick+=1;
						document.getElementById('btnDownload').hidden = false;
						document.getElementById('txtMS').value = document.getElementById('txtMs').value;
						break;
					default :
						alert("Full");
						break;
				}
			}
		}
		
		function load(){

			var element = document.getElementsByClassName('picture');
			var masv = document.getElementById('txtMs').value;
			console.log(masv);
			var i;
			for (i = 0 ; i < element.length ; i++) {
				var dataURL = element[i].toDataURL("image/png", 1.0);
				downloadImage(dataURL,masv+"_"+(i+1));
			}
		}
        function downloadImage(data, filename = 'image/untitled.png') {
		    var a = document.createElement('a');
		    // a.setAttribute('download', filename);
		    a.href = data;
		    a.download = filename;
		    document.body.appendChild(a);
		    a.click();
		    document.getElementById('btnDownload').hidden = true;
		    document.getElementById('btnsub').hidden = false;
		}

	</script> 
	
</body>
</html>
